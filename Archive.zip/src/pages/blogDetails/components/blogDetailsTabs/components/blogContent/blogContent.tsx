

const BlogContent = () => {
  return (
    <>
    <h1 className='font-bold'>Headline Replace Here</h1>
    <p className='text-gray-300'>Lorem ipsum dolor sit amet consectetur. Sagittis sed at elit mollis consequat. Magna at sed vitae pretium eget arcu sed nunc. Tincidunt malesuada tincidunt facilisi scelerisque mollis suscipit nec tellus. Neque in amet sodales libero cras placerat lorem. Non sed dolor tincidunt placerat. Ac blandit viverra at magna. Ac dolor at neque netus magna phasellus elit sit.</p>
    </>
  )
}

export default BlogContent