import ProductTable from "./components/productsTable/productTable"



const OrderSummary = () => {
  return (
    <>
    <h3 className="font-semibold mb-3">Order Summary</h3>
   <ProductTable/>
    </>
  )
}

export default OrderSummary