import { Dispatch, SetStateAction } from "react";

export interface BasketProps{
    setIsOpenShoppingCard:Dispatch<SetStateAction<boolean>>
}