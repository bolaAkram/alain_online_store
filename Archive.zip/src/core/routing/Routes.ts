export const ROUTES = {
    SLASH:"/",
    HOME:"/home",
    BLOGS:"/blogs",
    CONTACT_US:"/contact-us",
    PRODUCT_DETAILS:"/product-details",
    PRODUCTS_FILTER:"/products-filter",
    SUMMARY:"/summary",
    BLOG_DETAILS:"/blog-details",
    POLICY:"/policy",
    RETURNS:"/returns",
    TERMS:"/terms",
    LOGIN:"/login"

}